-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 26, 2022 at 03:11 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pinnacle`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `phone` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`name`, `password`, `phone`) VALUES
('admin', 'admin123', 123456);

-- --------------------------------------------------------

--
-- Table structure for table `employee_list`
--

CREATE TABLE `employee_list` (
  `ID` int(100) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Designation` varchar(100) NOT NULL,
  `Number` int(250) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Salary` int(100) NOT NULL,
  `Joining_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee_list`
--

INSERT INTO `employee_list` (`ID`, `Name`, `Designation`, `Number`, `Email`, `Salary`, `Joining_date`) VALUES
(1, 'Samiul Alim', 'Manager', 1765546436, 'siam@siam.com', 55080, '2019-03-03'),
(2, 'jamal', 'accountant', 56654465, 'jamal@jamal.com', 28661, '2019-12-03'),
(3, 'kamal', 'sales', 786897, 'kamal@kamal.com', 41800, '2019-03-04'),
(4, 'hasan', 'sales', 76786887, 'hasan@hasan.com', 42010, '2019-03-02'),
(5, 'barak obama', 'staff', 267352722, 'obama@obama.com', 18000, '2019-02-03'),
(6, 'elon mask', 'staff', 176539438, 'mask@mask.com', 19500, '2019-06-07'),
(7, 'Roton tata', 'staff', 1254645465, 'tata@tata.tata', 15000, '2019-03-02'),
(8, 'Mukesh ambani', 'staff', 1983673744, 'nil@nitin.mukesh', 1125, '2019-12-03');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `code` int(11) NOT NULL,
  `item_name` varchar(50) NOT NULL,
  `item_rank` int(50) NOT NULL,
  `price` int(255) NOT NULL,
  `date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`code`, `item_name`, `item_rank`, `price`, `date`) VALUES
(1, 'Chicken Pasta', 0, 110, ''),
(2, '      Chowmein', 0, 110, 'Fri Jul 01 07:00:09 BDT 2022'),
(3, '     French Fry', 0, 110, 'Sat Jul 02 07:00:31 BDT 2022'),
(4, 'Chicken Lolipop', 0, 110, 'Sun Jul 24 03:39:10 BDT 2022'),
(5, 'Chicken Wings', 0, 110, 'Sun Jul 24 03:38:49 BDT 2022'),
(6, '   Egg khichuri', 0, 100, 'Sat Jul 09 07:00:56 BDT 2022'),
(7, '     Briyani half', 9, 120, 'Tue Jul 19 07:01:20 BDT 2022'),
(8, '      Tehari half', 0, 180, 'Sun Jul 03 07:06:07 BDT 2022'),
(9, '             Lassi', 0, 110, 'Tue Jul 12 07:01:49 BDT 2022'),
(10, '    Lemonade', 10, 110, 'Sun Jul 17 07:07:52 BDT 2022'),
(11, '   Oreo Shake', 0, 110, 'Fri Jul 01 07:02:28 BDT 2022'),
(12, '    Soft Drinks', 0, 140, 'Wed Jul 20 07:03:30 BDT 2022');

-- --------------------------------------------------------

--
-- Table structure for table `notes`
--

CREATE TABLE `notes` (
  `serial_no` int(50) NOT NULL,
  `notes` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `notes`
--

INSERT INTO `notes` (`serial_no`, `notes`, `date`) VALUES
(12, 'Bread is all sold out', '2022-07-22'),
(13, 'Extra 6000 Tk  cost for liability', '2022-07-24');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order no` int(100) NOT NULL,
  `date` varchar(20) NOT NULL,
  `pcode` varchar(100) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `quantity` int(100) NOT NULL,
  `price` int(100) NOT NULL,
  `amount` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order no`, `date`, `pcode`, `item_name`, `quantity`, `price`, `amount`) VALUES
(6, '2022-05-10', '1', 'Chicken Pasta', 2, 110, 220),
(7, '2022-05-11', '2', 'Chowmein', 1, 110, 110),
(8, '2022-07-16', '2', 'Chowmein', 3, 110, 330),
(9, '2022-07-17', '1', 'Chicken Pasta', 4, 110, 440),
(10, '2022-07-17', '2', 'Chowmein', 3, 110, 330),
(11, '2022-07-17', '1', 'Chicken Pasta', 1, 110, 110),
(12, '2022-05-12', '2', 'Chowmein', 1, 110, 110),
(13, '2022-07-02', '1', 'Chicken Pasta', 1, 110, 110),
(14, '2022-07-20', '1', 'Chicken Pasta', 2, 110, 220),
(15, '2022-07-23', '7', 'Briyani', 1, 120, 120),
(16, '2022-07-23', '6', 'Egg khichuri', 2, 100, 200),
(17, '2022-07-24', '8', 'Tehari', 1, 80, 80),
(18, '2022-07-24', '5', 'Wings', 1, 110, 110),
(19, '2022-07-24', '6', 'Egg khichuri', 2, 100, 200),
(20, '2022-07-24', '5', 'Chicken Wings', 1, 110, 110),
(21, '2022-07-24', '8', 'Tehari half', 1, 80, 80),
(22, '2022-07-24', '3', 'French Fry', 1, 110, 110),
(23, '2022-07-31', '8', 'Tehari half', 1, 80, 80),
(24, '2022-07-31', '3', 'French Fry', 2, 110, 220),
(25, '2022-07-17', '3', 'French Fry', 1, 110, 110),
(26, '2022-07-17', '4', 'Chicken Lolipop', 3, 110, 330),
(27, '2022-07-17', '5', 'Chicken Wings', 1, 110, 110),
(28, '2022-07-17', '1', 'Chicken Pasta', 1, 110, 110),
(29, '2022-07-17', '8', 'Tehari half', 1, 80, 80),
(30, '2022-07-17', '12', 'Soft Drinks', 1, 40, 40),
(31, '2022-07-26', '1', 'Chicken Pasta', 1, 110, 110),
(32, '2022-07-26', '2', '      Chowmein', 1, 110, 110),
(33, '2022-07-26', '7', '     Briyani half', 1, 120, 120),
(34, '2022-07-26', '9', '             Lassi', 1, 110, 110),
(35, '2022-07-26', '1', 'Chicken Pasta', 1, 110, 110),
(36, '2022-07-26', '2', '      Chowmein', 1, 110, 110),
(37, '2022-07-26', '5', '      Chowmein', 1, 110, 110),
(38, '2022-07-26', '8', '     Tehari half', 1, 180, 180),
(39, '2022-07-21', '1', 'Chicken Pasta', 1, 110, 110),
(40, '2022-07-21', '8', '      Tehari half', 1, 180, 180),
(41, '2022-07-21', '10', '     Lemonade', 1, 110, 110);

-- --------------------------------------------------------

--
-- Table structure for table `res`
--

CREATE TABLE `res` (
  `Num` int(100) NOT NULL,
  `NAME` varchar(100) NOT NULL,
  `EMAIL` varchar(100) NOT NULL,
  `PHONE` int(100) NOT NULL,
  `GUEST` int(100) NOT NULL,
  `DATE` varchar(50) NOT NULL,
  `TIME` varchar(100) NOT NULL,
  `NOTE` varchar(100) NOT NULL,
  `STATUS` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `res`
--

INSERT INTO `res` (`Num`, `NAME`, `EMAIL`, `PHONE`, `GUEST`, `DATE`, `TIME`, `NOTE`, `STATUS`) VALUES
(1, 'Taylor', 'taylor@gmail.com', 777777, 2, '2022-07-01', '7.00 pm', 'No comments', 'Reserved'),
(2, 'Harry', 'harry@gmail.com', 888888, 8, '2022-07-15', '4.30 pm', 'No comments', 'Cancelled'),
(4, 'Array', 'array@gmail.com', 555555, 5, '2022-07-22', '1.30 pm', 'No comments', 'Done'),
(5, 'Akon', 'akon@gmail.com', 454577, 7, '2022-07-17', '10.00 am', 'No comments', 'Reserved');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`code`);

--
-- Indexes for table `notes`
--
ALTER TABLE `notes`
  ADD PRIMARY KEY (`serial_no`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order no`);

--
-- Indexes for table `res`
--
ALTER TABLE `res`
  ADD PRIMARY KEY (`Num`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `code` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `notes`
--
ALTER TABLE `notes`
  MODIFY `serial_no` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `res`
--
ALTER TABLE `res`
  MODIFY `Num` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
